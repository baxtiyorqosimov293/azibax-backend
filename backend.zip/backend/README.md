# AziBax Backend Starter

FastAPI backend для AziBax.
