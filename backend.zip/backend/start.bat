@echo off
pip install -r requirements.txt
python seed_books.py
uvicorn app.main:app --reload
pause
