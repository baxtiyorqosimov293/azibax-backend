import json
from app.database import SessionLocal, Base, engine
from app.models import Book
from app.config import LIBRARY_PATH

Base.metadata.create_all(bind=engine)

def main():
    catalog_path = LIBRARY_PATH / "catalog.json"
    if not catalog_path.exists():
        print(f"catalog.json not found: {catalog_path}")
        print("Сначала скачай книги downloader-скриптом.")
        return

    data = json.loads(catalog_path.read_text(encoding="utf-8"))
    db = SessionLocal()
    added = 0
    updated = 0

    try:
        for item in data:
            gutenberg_id = str(item.get("gutenberg_id") or "").strip() or None
            title = (item.get("title") or "").strip()
            author = (item.get("author") or "").strip()
            genre = (item.get("genre") or "").strip()
            file_path = (item.get("file_path") or "").strip() or None

            if not title or not author or not genre:
                continue

            existing = db.query(Book).filter(Book.gutenberg_id == gutenberg_id).first() if gutenberg_id else None
            if existing:
                existing.title = title
                existing.author = author
                existing.genre = genre
                existing.file_path = file_path
                updated += 1
                continue

            db.add(Book(
                gutenberg_id=gutenberg_id,
                title=title,
                author=author,
                genre=genre,
                file_path=file_path,
                description=f"{title} by {author}",
                language="en",
            ))
            added += 1

        db.commit()
        print(f"Import complete. Added: {added}, Updated: {updated}")
    finally:
        db.close()

if __name__ == "__main__":
    main()
